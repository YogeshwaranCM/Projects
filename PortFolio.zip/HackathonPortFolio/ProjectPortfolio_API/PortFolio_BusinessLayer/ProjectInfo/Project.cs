﻿using PortFolio_DataAccessLayer.Data;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PortFolio_BusinessLayer.ProjectInfo
{

    public class Project
    {
        public List<ProjectListDTO> GetProjectList(string name, int generalId)
        {
            List<ProjectListDTO> project = new List<ProjectListDTO>();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    if (generalId != null && generalId != 0)
                    {
                        if (string.IsNullOrEmpty(name))
                        {
                            project = (from list in dbContext.ProjectList
                                       join generalDomain in dbContext.GeneralDomain on list.GeneralDomainId equals generalDomain.Id into generals
                                       from general in generals.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join technicalDomain in dbContext.TechnicalDomain on list.TechnicalDomainId equals technicalDomain.Id into technicals
                                       from technical in technicals.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join customer in dbContext.ProjectCustomer on list.Id equals customer.ProjectId
                                       join controlProject in dbContext.ProjectControl on list.Id equals controlProject.ProjectId into controls
                                       from control in controls.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join projectImage in dbContext.ProjectImage on list.Id equals projectImage.ProjectId into images
                                       from image in images.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       where !list.IsDeleted && !customer.IsDeleted && general.Id == generalId
                                       select new ProjectListDTO
                                       {
                                           Name = list.Name,
                                           Description = list.Description,
                                           StartedDate = list.StartedDate,
                                           CompletedDate = list.CompletedDate,
                                           StatusId = list.StatusId,
                                           IsPublic = list.IsPublic,
                                           GeneralDomainId = general != null ? general.Id : 0,
                                           TechnicalDomainId = technical != null ? technical.Id : 0,
                                           ProjectSiteLink = list.ProjectSiteLink,
                                           ProjectCustomerId = customer.Id,
                                           ModifiedDate = list.ModifiedDate,
                                           Url = image != null ? image.Url : string.Empty,
                                           CustomerName = customer.Name,
                                           CompanyName = customer.CompanyName,
                                           Address = customer.Address,
                                           MobileNo = customer.MobileNo,
                                           Email = customer.Email,
                                           Country = customer.Country,
                                           State = customer.State,
                                           ControlName = control != null ? control.ControlName : string.Empty,
                                           IsSyncfusionControl = control != null ? control.IsSycfusionControl : false,
                                           SiteLink = control != null ? control.SiteLink : string.Empty,
                                       }).ToList();

                            //projects = Mapper.Map<ICollection<ProjectList>, ICollection<ProjectListDTO>>(project).ToList();
                        }
                        else
                        {
                            project = (from list in dbContext.ProjectList
                                       join generalDomain in dbContext.GeneralDomain on list.GeneralDomainId equals generalDomain.Id into generals
                                       from general in generals.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join technicalDomain in dbContext.TechnicalDomain on list.TechnicalDomainId equals technicalDomain.Id into technicals
                                       from technical in technicals.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join customer in dbContext.ProjectCustomer on list.Id equals customer.ProjectId
                                       join controlProject in dbContext.ProjectControl on list.Id equals controlProject.ProjectId into controls
                                       from control in controls.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join projectImage in dbContext.ProjectImage on list.Id equals projectImage.ProjectId into images
                                       from image in images.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       where !list.IsDeleted && list.Name == name && general.Id == generalId
                                       && !customer.IsDeleted
                                       select new ProjectListDTO
                                       {
                                           Name = list.Name,
                                           Description = list.Description,
                                           StartedDate = list.StartedDate,
                                           CompletedDate = list.CompletedDate,
                                           StatusId = list.StatusId,
                                           IsPublic = list.IsPublic,
                                           GeneralDomainId = general != null ? general.Id : 0,
                                           TechnicalDomainId = technical != null ? technical.Id : 0,
                                           ProjectSiteLink = list.ProjectSiteLink,
                                           ProjectCustomerId = customer.Id,
                                           ModifiedDate = list.ModifiedDate,
                                           Url = image != null ? image.Url : string.Empty,
                                           CustomerName = customer.Name,
                                           CompanyName = customer.CompanyName,
                                           Address = customer.Address,
                                           MobileNo = customer.MobileNo,
                                           Email = customer.Email,
                                           Country = customer.Country,
                                           State = customer.State,
                                           ControlName = control != null ? control.ControlName : string.Empty,
                                           IsSyncfusionControl = control != null ? control.IsSycfusionControl : false,
                                           SiteLink = control != null ? control.SiteLink : string.Empty,
                                       }).ToList();
                            //projects = Mapper.Map<ICollection<ProjectList>, ICollection<ProjectListDTO>>(project).ToList();
                        }
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return project;
        }

        public List<ProjectListDTO> GetProject(string name, int technicalId)
        {
            List<ProjectListDTO> project = new List<ProjectListDTO>();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    if (technicalId != null && technicalId != 0)
                    {
                        if (string.IsNullOrEmpty(name))
                        {
                            project = (from list in dbContext.ProjectList
                                       join generalDomain in dbContext.GeneralDomain on list.GeneralDomainId equals generalDomain.Id into generals
                                       from general in generals.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join technicalDomain in dbContext.TechnicalDomain on list.TechnicalDomainId equals technicalDomain.Id into technicals
                                       from technical in technicals.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join customer in dbContext.ProjectCustomer on list.Id equals customer.ProjectId
                                       join controlProject in dbContext.ProjectControl on list.Id equals controlProject.ProjectId into controls
                                       from control in controls.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join projectImage in dbContext.ProjectImage on list.Id equals projectImage.ProjectId into images
                                       from image in images.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       where !list.IsDeleted && !customer.IsDeleted && technical.Id == technicalId
                                       select new ProjectListDTO
                                       {
                                           Name = list.Name,
                                           Description = list.Description,
                                           StartedDate = list.StartedDate,
                                           CompletedDate = list.CompletedDate,
                                           StatusId = list.StatusId,
                                           IsPublic = list.IsPublic,
                                           GeneralDomainId = general != null ? general.Id : 0,
                                           TechnicalDomainId = technical != null ? technical.Id : 0,
                                           ProjectSiteLink = list.ProjectSiteLink,
                                           ProjectCustomerId = customer.Id,
                                           ModifiedDate = list.ModifiedDate,
                                           Url = image != null ? image.Url : string.Empty,
                                           CustomerName = customer.Name,
                                           CompanyName = customer.CompanyName,
                                           Address = customer.Address,
                                           MobileNo = customer.MobileNo,
                                           Email = customer.Email,
                                           Country = customer.Country,
                                           State = customer.State,
                                           ControlName = control != null ? control.ControlName : string.Empty,
                                           IsSyncfusionControl = control != null ? control.IsSycfusionControl : false,
                                           SiteLink = control != null ? control.SiteLink : string.Empty,
                                       }).ToList();

                            //projects = Mapper.Map<ICollection<ProjectList>, ICollection<ProjectListDTO>>(project).ToList();
                        }
                        else
                        {
                            project = (from list in dbContext.ProjectList
                                       join generalDomain in dbContext.GeneralDomain on list.GeneralDomainId equals generalDomain.Id into generals
                                       from general in generals.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join technicalDomain in dbContext.TechnicalDomain on list.TechnicalDomainId equals technicalDomain.Id into technicals
                                       from technical in technicals.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join customer in dbContext.ProjectCustomer on list.Id equals customer.ProjectId
                                       join controlProject in dbContext.ProjectControl on list.Id equals controlProject.ProjectId into controls
                                       from control in controls.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       join projectImage in dbContext.ProjectImage on list.Id equals projectImage.ProjectId into images
                                       from image in images.Where(a => !a.IsDeleted).DefaultIfEmpty()
                                       where !list.IsDeleted && list.Name == name && technical.Id == technicalId
                                       && !customer.IsDeleted
                                       select new ProjectListDTO
                                       {
                                           Name = list.Name,
                                           Description = list.Description,
                                           StartedDate = list.StartedDate,
                                           CompletedDate = list.CompletedDate,
                                           StatusId = list.StatusId,
                                           IsPublic = list.IsPublic,
                                           GeneralDomainId = general != null ? general.Id : 0,
                                           TechnicalDomainId = technical != null ? technical.Id : 0,
                                           ProjectSiteLink = list.ProjectSiteLink,
                                           ProjectCustomerId = customer.Id,
                                           ModifiedDate = list.ModifiedDate,
                                           Url = image != null ? image.Url : string.Empty,
                                           CustomerName = customer.Name,
                                           CompanyName = customer.CompanyName,
                                           Address = customer.Address,
                                           MobileNo = customer.MobileNo,
                                           Email = customer.Email,
                                           Country = customer.Country,
                                           State = customer.State,
                                           ControlName = control != null ? control.ControlName : string.Empty,
                                           IsSyncfusionControl = control != null ? control.IsSycfusionControl : false,
                                           SiteLink = control != null ? control.SiteLink : string.Empty,
                                       }).ToList();
                            //projects = Mapper.Map<ICollection<ProjectList>, ICollection<ProjectListDTO>>(project).ToList();
                        }
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return project;
        }

        public ResponseDTO AddProject(ProjectListDTO projectListDTO)
        {
            var response = new ResponseDTO();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    var project = new ProjectList
                    {
                        Name = projectListDTO.Name,
                        Description = projectListDTO.Description,
                        StartedDate = projectListDTO.StartedDate,
                        CompletedDate = projectListDTO.CompletedDate,
                        StatusId = projectListDTO.StatusId,
                        GeneralDomainId = projectListDTO.GeneralDomainId,
                        TechnicalDomainId = projectListDTO.TechnicalDomainId,
                        IsPublic = projectListDTO.IsPublic,
                        ProjectSiteLink = projectListDTO.ProjectSiteLink
                    };
                    dbContext.ProjectList.Add(project);
                    dbContext.SaveChanges();


                    var projectImage = new ProjectImage
                    {
                        ProjectId = project.Id,
                        Url = projectListDTO.Url
                    };
                    dbContext.ProjectImage.Add(projectImage);
                    dbContext.SaveChanges();

                    var customer = new ProjectCustomer
                    {
                        Name = projectListDTO.CustomerName,
                        CompanyName = projectListDTO.CompanyName,
                        Address = projectListDTO.Address,
                        Email = projectListDTO.Email,
                        MobileNo = projectListDTO.MobileNo,
                        Country = projectListDTO.Country,
                        State = projectListDTO.State,
                        CreatedDate = projectListDTO.CreatedDate,
                        ProjectId = project.Id,
                    };
                    dbContext.ProjectCustomer.Add(customer);
                    dbContext.SaveChanges();

                    var member = new ProjectMembers
                    {
                        Name = projectListDTO.MemberName,
                        IsActive = projectListDTO.IsActive,
                        EmployeeId = projectListDTO.EmployeeId,
                        DesignationId = projectListDTO.DesignationId,
                        ProjectId = project.Id,
                        ModifiedDate = DateTime.UtcNow,
                    };
                    dbContext.ProjectMembers.Add(member);
                    dbContext.SaveChanges();

                    var control = new ProjectControl
                    {
                        ControlName = projectListDTO.ControlName,
                        IsSycfusionControl = projectListDTO.IsSyncfusionControl,
                        SiteLink = projectListDTO.SiteLink,
                        CreatedDate = projectListDTO.CreatedDate,
                        ModifiedDate = projectListDTO.ModifiedDate,
                        ProjectId = project.Id,
                    };
                    dbContext.ProjectControl.Add(control);
                    dbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseDTO UpdateProject(ProjectListDTO projectListDTO)
        {
            var response = new ResponseDTO();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    var project = dbContext.ProjectList.Where(a => a.Id == projectListDTO.Id && !a.IsDeleted).FirstOrDefault();
                    if (project != null)
                    {
                        project.Name = projectListDTO.Name;
                        project.Description = projectListDTO.Description;
                        project.StartedDate = projectListDTO.StartedDate;
                        project.CompletedDate = projectListDTO.CompletedDate;
                        project.StatusId = projectListDTO.StatusId;
                        project.GeneralDomainId = projectListDTO.GeneralDomainId;
                        project.TechnicalDomainId = projectListDTO.TechnicalDomainId;
                        project.IsPublic = projectListDTO.IsPublic;
                        project.ProjectSiteLink = projectListDTO.ProjectSiteLink;
                        project.ModifiedDate = DateTime.UtcNow;

                        dbContext.SaveChanges();

                        response.IsSuccess = true;
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ErrorMessage = "The Project does not exists.";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseDTO DeleteProject(int projectId)
        {
            var response = new ResponseDTO();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    var project = dbContext.ProjectList.Where(a => a.Id == projectId && !a.IsDeleted).FirstOrDefault();
                    if (project != null)
                    {
                        project.IsDeleted = true;
                        project.ModifiedDate = DateTime.UtcNow;

                        dbContext.SaveChanges();

                        response.IsSuccess = true;

                        var images = dbContext.ProjectImage.Where(a => a.ProjectId == projectId && !a.IsDeleted).ToList();
                        if (images != null)
                        {
                            foreach (var image in images)
                            {
                                image.IsDeleted = true;

                                dbContext.SaveChanges();
                            }
                        }

                        var customer = dbContext.ProjectCustomer.Where(a => a.ProjectId == projectId && !a.IsDeleted).FirstOrDefault();
                        if (customer != null)
                        {
                            customer.IsDeleted = true;

                            dbContext.SaveChanges();
                        }

                        var members = dbContext.ProjectMembers.Where(a => a.ProjectId == projectId && !a.IsDeleted).ToList();
                        if (members != null)
                        {
                            foreach (var member in members)
                            {
                                member.IsDeleted = true;

                                dbContext.SaveChanges();
                            }
                        }

                        var controls = dbContext.ProjectControl.Where(a => a.ProjectId == projectId && !a.IsDeleted).ToList();
                        if (controls != null)
                        {
                            foreach (var control in controls)
                            {
                                control.IsDeleted = true;

                                dbContext.SaveChanges();
                            }
                        }
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ErrorMessage = "The Project does not exists.";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
    }
}

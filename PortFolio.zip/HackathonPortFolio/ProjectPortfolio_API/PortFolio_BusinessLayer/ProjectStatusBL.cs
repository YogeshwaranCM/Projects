﻿using AutoMapper;
using PortFolio_DataAccessLayer.Data;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortFolio_BusinessLayer
{
    public class ProjectStatusBL
    {
        public List<ProjectStatusDTO> GetProjectStatus()
        {
            List<ProjectStatusDTO> projectStatusDTOs = new List<ProjectStatusDTO>();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    projectStatusDTOs = Mapper.Map<ICollection<ProjectStatus>, ICollection<ProjectStatusDTO>>(dbContext.ProjectStatus.ToList()).ToList();
                    if (projectStatusDTOs.Any())
                        return projectStatusDTOs;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return projectStatusDTOs;
        }
    }
}

﻿using AutoMapper;
using PortFolio_DataAccessLayer.Data;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortFolio_BusinessLayer
{
    public class ProjectControlBL
    {
        public List<ProjectControlDTO> GetProjectControls(int? projectId)
        {
            List<ProjectControlDTO> projectControlDTOs = new List<ProjectControlDTO>();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    if (projectId > 0)
                    {
                        var projectControls = dbContext.ProjectControl.Where(a => !a.IsDeleted && a.ProjectId == projectId).ToList();
                        if (projectControls.Any())
                        {
                            return projectControlDTOs = Mapper.Map<ICollection<ProjectControl>, ICollection<ProjectControlDTO>>(projectControls).ToList();                            
                        }
                    }
                    else
                    {
                        var projectControls = dbContext.ProjectControl.Where(a => !a.IsDeleted).ToList();
                        if (projectControls.Any())
                        {
                            return projectControlDTOs = Mapper.Map<ICollection<ProjectControl>, ICollection<ProjectControlDTO>>(projectControls).ToList();
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return projectControlDTOs;
        }

        public ResponseDTO AddProjectControl(List<ProjectControlDTO> projectControlDTOs)
        {
            var response = new ResponseDTO();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    foreach (var projectControl in projectControlDTOs)
                    {
                        var newProjectControl = new ProjectControl()
                        {
                            ProjectId = projectControl.ProjectId,
                            ControlName = projectControl.ControlName,
                            IsSycfusionControl = projectControl.IsSyncfusionControl,
                            SiteLink = projectControl.SiteLink,
                            CreatedDate = DateTime.Now,
                            ModifiedDate = DateTime.Now,
                            IsDeleted = false
                        };
                        dbContext.ProjectControl.Add(newProjectControl);
                    }

                    dbContext.SaveChanges();
                    response.IsSuccess = true;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseDTO UpdateProjectControl(ProjectControlDTO projectControlDTO)
        {
            var response = new ResponseDTO();
            try
            {
                if (projectControlDTO.Id > 0)
                {
                    using (var dbContext = new PortfolioEntities())
                    {
                        var projectControl = dbContext.ProjectControl.Where(a => a.Id == projectControlDTO.Id && !a.IsDeleted).FirstOrDefault();
                        if (projectControl != null)
                        {
                            projectControl.ProjectId = projectControl.ProjectId;
                            projectControl.ControlName = projectControl.ControlName;
                            projectControl.IsSycfusionControl = projectControl.IsSycfusionControl;
                            projectControl.SiteLink = projectControl.SiteLink;
                            projectControl.ModifiedDate = DateTime.Now;

                            dbContext.SaveChanges();
                            response.IsSuccess = true;
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.ErrorMessage = "Invalid project control id";
                        }
                    }
                }
                else
                {
                    response.IsSuccess = false;
                    response.ErrorMessage = "Invalid project control id";
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseDTO DeleteProjectControl(int projectControlId)
        {
            var response = new ResponseDTO();
            try
            {
                if(projectControlId > 0)
                {
                    using (var dbContext = new PortfolioEntities())
                    {
                        var projectControl = dbContext.ProjectControl.Where(a => (a.Id == projectControlId) && !a.IsDeleted).FirstOrDefault();
                        if(projectControl != null)
                        {
                            projectControl.IsDeleted = true;
                            projectControl.ModifiedDate = DateTime.Now;

                            dbContext.SaveChanges();
                            response.IsSuccess = true;
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.ErrorMessage = "Invalid project status id or invalid project id";
                        }
                    }
                }
                else
                {
                    response.IsSuccess = false;
                    response.ErrorMessage = "Invalid project status id or invalid project id";
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return response;
        }        
    }
}

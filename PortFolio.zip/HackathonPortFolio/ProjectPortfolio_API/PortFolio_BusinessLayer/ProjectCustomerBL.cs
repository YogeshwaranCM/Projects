﻿using AutoMapper;
using PortFolio_DataAccessLayer.Data;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortFolio_BusinessLayer
{
    public class ProjectCustomerBL
    {
        public List<ProjectCustomerDTO> GetProjectCustomers(int? projectID)
        {
            List<ProjectCustomerDTO> projectCustomerDTOs = new List<ProjectCustomerDTO>();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    if (projectID > 0)
                    {
                        var projectCustomers = dbContext.ProjectCustomer.Where(a => a.ProjectId == projectID && !a.IsDeleted).ToList();
                        if (projectCustomers.Any())
                        {
                            return projectCustomerDTOs = Mapper.Map<ICollection<ProjectCustomer>, ICollection<ProjectCustomerDTO>>(projectCustomers).ToList();
                        }
                    }
                    else
                    {
                        var projectCustomers = dbContext.ProjectCustomer.Where(a => !a.IsDeleted).ToList();
                        if (projectCustomers.Any())
                        {
                            return projectCustomerDTOs = Mapper.Map<ICollection<ProjectCustomer>, ICollection<ProjectCustomerDTO>>(projectCustomers).ToList();
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return projectCustomerDTOs;
        }

        public ResponseDTO AddOrUpdateProjectCustomer(ProjectCustomerDTO projectCustomerDTO)
        {
            var response = new ResponseDTO();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    if (projectCustomerDTO.Id > 0)
                    {
                        var projectCustomer = dbContext.ProjectCustomer.Where(a => a.Id == projectCustomerDTO.Id && !a.IsDeleted).FirstOrDefault();
                        if(projectCustomer != null)
                        {
                            projectCustomer.Name = projectCustomerDTO.Name;
                            projectCustomer.ProjectId = projectCustomerDTO.ProjectId;
                            projectCustomer.CompanyName = projectCustomerDTO.CompanyName;
                            projectCustomer.Address = projectCustomerDTO.Address;
                            projectCustomer.MobileNo = projectCustomerDTO.MobileNo;
                            projectCustomer.Email = projectCustomerDTO.Email;
                            projectCustomer.Country = projectCustomerDTO.Country;
                            projectCustomer.State = projectCustomerDTO.State;
                            projectCustomer.ModifiedDate = DateTime.Now;

                            response.IsSuccess = true;
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.ErrorMessage = "Invalid project customer id.";
                        }
                    }
                    else
                    {
                        var projectCustomer = new ProjectCustomer()
                        {
                            Name = projectCustomerDTO.Name,
                            ProjectId = projectCustomerDTO.ProjectId,
                            CompanyName = projectCustomerDTO.CompanyName,
                            Address = projectCustomerDTO.Address,
                            MobileNo = projectCustomerDTO.MobileNo,
                            Email = projectCustomerDTO.Email,
                            Country = projectCustomerDTO.Country,
                            State = projectCustomerDTO.State,
                            CreatedDate = DateTime.Now,
                            ModifiedDate = DateTime.Now,
                            IsDeleted = false
                        };
                        dbContext.ProjectCustomer.Add(projectCustomer);
                        response.IsSuccess = true;
                    }

                    dbContext.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseDTO DeleteProjectCustomer(int customerId)
        {
            var response = new ResponseDTO();
            try
            {
                if(customerId > 0)
                {
                    using (var dbContext = new PortfolioEntities())
                    {
                        var projectCustomer = dbContext.ProjectCustomer.Where(a => a.Id == customerId && !a.IsDeleted).FirstOrDefault();
                        if(projectCustomer != null)
                        {
                            projectCustomer.ModifiedDate = DateTime.Now;
                            projectCustomer.IsDeleted = true;

                            response.IsSuccess = true;
                            dbContext.SaveChanges();
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.ErrorMessage = "Invalid project customer id.";
                        }
                    }
                }
                else
                {
                    response.IsSuccess = false;
                    response.ErrorMessage = "Invalid project customer id.";
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return response;
        }
    }
}

﻿using AutoMapper;
using PortFolio_DataAccessLayer.Data;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortFolio_BusinessLayer
{
    public class TechnicalDomineBL
    {
        public List<TechnicalDomainDTO> GetTechnicalDomains()
        {
            List<TechnicalDomainDTO> technicalDomainDTOs = new List<TechnicalDomainDTO>();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    var technicalDomines = dbContext.TechnicalDomain.Where(a => !a.IsDeleted).ToList();
                    if (technicalDomines.Any())
                        return technicalDomainDTOs = Mapper.Map<ICollection<TechnicalDomain>, ICollection<TechnicalDomainDTO>>(technicalDomines).ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return technicalDomainDTOs;
        }

        public ResponseDTO AddOrUpdateTechnicalDomine(TechnicalDomainDTO technicalDomainDTO)
        {
            var response = new ResponseDTO();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    if (technicalDomainDTO.Id > 0)
                    {
                        var technicalDomine = dbContext.TechnicalDomain.Where(a => a.Id == technicalDomainDTO.Id && !a.IsDeleted).FirstOrDefault();
                        if (technicalDomine != null)
                        {
                            technicalDomine.Name = technicalDomainDTO.Name;
                            technicalDomine.CreatedBy = technicalDomainDTO.CreatedBy;
                            technicalDomine.ModifiedDate = DateTime.Now;

                            response.IsSuccess = true;
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.ErrorMessage = "Invalid technical domine id.";
                        }
                    }
                    else
                    {
                        var technicalDomine = new TechnicalDomain()
                        {
                            Name = technicalDomainDTO.Name,
                            CreatedBy = technicalDomainDTO.CreatedBy,
                            CreatedDate = DateTime.Now,
                            ModifiedDate = DateTime.Now,
                            IsDeleted = false
                        };
                        dbContext.TechnicalDomain.Add(technicalDomine);
                        response.IsSuccess = true;
                    }

                    dbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseDTO DeleteTechnicalDomine(int domainId)
        {
            var response = new ResponseDTO();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    if (domainId > 0)
                    {
                        var technicalDomine = dbContext.TechnicalDomain.Where(a => a.Id == domainId && !a.IsDeleted).FirstOrDefault();
                        if (technicalDomine != null)
                        {
                            technicalDomine.IsDeleted = true;
                            technicalDomine.ModifiedDate = DateTime.Now;

                            dbContext.SaveChanges();
                            response.IsSuccess = true;
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.ErrorMessage = "Invalid technical domine id.";
                        }
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ErrorMessage = "Invalid technical domine id.";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
    }
}

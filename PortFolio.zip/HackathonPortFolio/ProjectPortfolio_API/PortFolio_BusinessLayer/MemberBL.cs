﻿using AutoMapper;
using PortFolio_DataAccessLayer.Data;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortFolio_BusinessLayer
{
    public class MemberBL
    {
        public List<ProjectMembersDTO> GetProjectMembers(int? projectId)
        {
            List<ProjectMembersDTO> projectMembersDTOs = new List<ProjectMembersDTO>();

            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    List<ProjectMembers> members = new List<ProjectMembers>();
                    if (projectId != null)
                        members = dbContext.ProjectMembers.Where(a => a.IsActive && a.ProjectId == projectId).ToList();
                    else
                        members = dbContext.ProjectMembers.Where(a => a.IsActive).ToList();

                    if (members.Any())
                    {
                        projectMembersDTOs = Mapper.Map<ICollection<ProjectMembers>, ICollection<ProjectMembersDTO>>(members).ToList();
                        return projectMembersDTOs;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projectMembersDTOs;
        }

        public ResponseDTO AddProjectMembers(List<ProjectMembersDTO> projectMembersDTOs)
        {
            var response = new ResponseDTO();

            try
            {
                using (var dbContext = new PortfolioEntities())
                {                   
                    foreach (var member in projectMembersDTOs)
                    {
                        var projectMember = new ProjectMembers
                        {
                            Name = member.Name,
                            EmployeeId = member.EmployeeId,
                            DesignationId = member.DesignationId,
                            ProjectId = member.ProjectId,
                            IsActive = true
                        };
                        dbContext.ProjectMembers.Add(projectMember);
                    }

                    response.IsSuccess = true;
                    dbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return response;
        }

        public ResponseDTO UpdateProjectMember(ProjectMembersDTO projectMembersDTO)
        {
            var response = new ResponseDTO();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    if (projectMembersDTO.Id > 0)
                    {
                        var projectMemer = dbContext.ProjectMembers.Where(a => a.Id == projectMembersDTO.Id && a.IsActive).FirstOrDefault();
                        if (projectMemer != null)
                        {
                            projectMemer.Name = projectMembersDTO.Name;
                            projectMemer.EmployeeId = projectMembersDTO.EmployeeId;
                            projectMemer.DesignationId = projectMembersDTO.DesignationId;
                            projectMemer.ProjectId = projectMembersDTO.ProjectId;
                            projectMemer.IsActive = projectMembersDTO.IsActive;

                            response.IsSuccess = true;
                        }
                        else
                        {
                            response.ErrorMessage = "Invalid member id";
                            response.IsSuccess = false;
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseDTO DeleteMember(int memberId)
        {
            var response = new ResponseDTO();
            try
            {
                if(memberId > 0)
                {
                    using (var dbContext = new PortfolioEntities())
                    {
                        var member = dbContext.ProjectMembers.Where(a => a.Id == memberId && a.IsActive).FirstOrDefault();
                        if(member != null)
                        {
                            member.IsActive = false;                            

                            response.IsSuccess = true;
                            dbContext.SaveChanges();
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.ErrorMessage = "Invalid member id";
                        }                        
                    }
                }
                else
                {
                    response.IsSuccess = false;
                    response.ErrorMessage = "Invalid member id";
                }
            }
            catch(Exception ex)
            {

            }

            return response;
        }
    }
}

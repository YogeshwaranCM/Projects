﻿using AutoMapper;
using PortFolio_DataAccessLayer.Data;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortFolio_BusinessLayer
{
    public class DesignationBL
    {
        public List<DesignationDTO> GetDesignations()
        {
            List<DesignationDTO> designationDTOs = new List<DesignationDTO>();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    var designations = dbContext.Designation.Where(a => !a.IsDeleted).ToList();
                    if(designations.Any())
                    {
                        return designationDTOs = Mapper.Map<ICollection<Designation>, ICollection<DesignationDTO>>(designations).ToList();
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return designationDTOs;
        }
    }
}

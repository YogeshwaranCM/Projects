﻿using AutoMapper;
using PortFolio_DataAccessLayer.Data;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortFolio_BusinessLayer
{
    public class GeneralDomineBL
    {
        public List<GeneralDomainDTO> GetGeneralDomains()
        {
            List<GeneralDomainDTO> generalDomainDTOs = new List<GeneralDomainDTO>();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    var generalDomines = dbContext.GeneralDomain.Where(a => !a.IsDeleted).ToList();
                    if(generalDomines.Any())
                        return generalDomainDTOs = Mapper.Map<ICollection<GeneralDomain>, ICollection<GeneralDomainDTO>>(generalDomines).ToList();
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return generalDomainDTOs;
        }

        public ResponseDTO AddOrUpdateGeneralDomine(GeneralDomainDTO generalDomainDTO)
        {
            var response = new ResponseDTO();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    if (generalDomainDTO.Id > 0)
                    {
                        var generalDomine = dbContext.GeneralDomain.Where(a => a.Id == generalDomainDTO.Id && !a.IsDeleted).FirstOrDefault();
                        if(generalDomine != null)
                        {
                            generalDomine.Name = generalDomainDTO.Name;
                            generalDomine.CreatedBy = generalDomainDTO.CreatedBy;
                            generalDomine.ModifiedDate = DateTime.Now;

                            response.IsSuccess = true;
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.ErrorMessage = "Invalid technical domine id.";
                        }
                    }
                    else
                    {
                        var generalDomine = new GeneralDomain()
                        {
                            Name = generalDomainDTO.Name,
                            CreatedBy = generalDomainDTO.CreatedBy,
                            CreatedDate = DateTime.Now,
                            ModifiedDate = DateTime.Now,
                            IsDeleted = false
                        };
                        dbContext.GeneralDomain.Add(generalDomine);
                        response.IsSuccess = true;
                    }

                    dbContext.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseDTO DeleteGeneralDomine(int domainId)
        {
            var response = new ResponseDTO();
            try
            {
                using (var dbContext = new PortfolioEntities())
                {
                    if(domainId > 0)
                    {
                        var generalDomine = dbContext.GeneralDomain.Where(a => a.Id == domainId && !a.IsDeleted).FirstOrDefault();
                        if(generalDomine != null)
                        {
                            generalDomine.IsDeleted = true;
                            generalDomine.ModifiedDate = DateTime.Now;

                            dbContext.SaveChanges();
                            response.IsSuccess = true;                            
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.ErrorMessage = "Invalid general domine id.";
                        }
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ErrorMessage = "Invalid general domine id.";
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return response;
        }
    }
}

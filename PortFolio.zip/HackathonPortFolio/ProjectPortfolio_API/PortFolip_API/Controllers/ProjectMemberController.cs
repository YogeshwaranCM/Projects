﻿using PortFolio_BusinessLayer;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;

namespace PortFolip_API.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]

    [RoutePrefix("api/projectmembers")]
    public class ProjectMemberController : ApiController
    {
        public ProjectMemberController()
        {

        }

        [Route("{projectId?}")]
        [HttpGet]
        public List<ProjectMembersDTO> GetProjectMembers(int? projectId)
        {
            List<ProjectMembersDTO> projectMembersDTOs = new List<ProjectMembersDTO>();
            try
            {
                MemberBL projectMember = new MemberBL();
                projectMembersDTOs = projectMember.GetProjectMembers(projectId);
                if (projectMembersDTOs.Any())
                {
                    return projectMembersDTOs;
                }
            }
            catch (Exception ex)
            {

            }
            return projectMembersDTOs;
        }

        [HttpPost]
        public ResponseDTO AddProjectMembers(List<ProjectMembersDTO> projectMembersDTOs)
        {
            var response = new ResponseDTO();
            try
            {
                MemberBL memberBL = new MemberBL();
                var projectMemberResponse = memberBL.AddProjectMembers(projectMembersDTOs);
                if (projectMemberResponse.IsSuccess)
                {
                    response.IsSuccess = true;
                    response.UserMessage = "Project members are successfully added.";
                }
                else
                {
                    response = projectMemberResponse;
                }
            }
            catch (Exception ex)
            {

            }
            return response;
        }

        [HttpPut]
        public ResponseDTO UpdateProjectMembers(ProjectMembersDTO projectMembersDTO)
        {
            var response = new ResponseDTO();
            try
            {
                MemberBL memberBL = new MemberBL();
                var projectMemberResponse = memberBL.UpdateProjectMember(projectMembersDTO);
                if (projectMemberResponse.IsSuccess)
                {
                    response.IsSuccess = true;
                    response.UserMessage = "Project member is updated successfully";
                }
                else
                {
                    response = projectMemberResponse;
                }
            }
            catch (Exception ex)
            {

            }

            return response;
        }

        [HttpDelete]
        public ResponseDTO DeleteProjectMember(int memberId)
        {
            var response = new ResponseDTO();
            try
            {
                MemberBL memberBL = new MemberBL();
                var projectMemberResponse = memberBL.DeleteMember(memberId);
                if (projectMemberResponse.IsSuccess)
                {
                    response.IsSuccess = true;
                    response.UserMessage = "Project member is successfully deleted.";
                }
                else
                {
                    response = projectMemberResponse;
                }
            }
            catch (Exception ex)
            {

            }
            return response;
        }

    }
}

﻿using System.Web.Http;
using System.Web.Http.Cors;

namespace PortFolip_API.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]

    [RoutePrefix("api/projectcontrol")]
    public class ProjectControlController : ApiController
    {
        //[HttpPost]
        //public ResponseDTO AddProjectControl(ProjectListDTO projectListDTO)
        //{
        //    ProjectControls project = new ProjectControls();
        //    var projects = project.AddProject(projectListDTO);
        //    return projects;
        //}
    }
}

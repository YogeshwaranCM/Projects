﻿using PortFolio_BusinessLayer.ProjectInfo;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;
using System.IO;
using System.Web;
using System.Net.Http;
using System.Net;

namespace PortFolip_API.Controllers
{

    [RoutePrefix("api/projects")]
    public class ProjectsController : ApiController
    {
        public ProjectsController()
        {

        }
       
        [HttpGet]
        public List<ProjectListDTO> GetProjectsList(string name, int generalId)
        {
            List<ProjectListDTO> projects = new List<ProjectListDTO>();
            try
            {
                Project project = new Project();
                projects = project.GetProjectList(name, generalId);

                if (projects.Any())
                {
                    return projects;
                }
                //var content = new StringContent(JsonConvert.SerializeObject(projects),
                //                Encoding.UTF8, "application/json");

            }
            catch (Exception ex)
            {

            }
            return projects;
        }

        [Route("getprojects")]
        [HttpGet]
        public List<ProjectListDTO> GetProjects()
        {
            string name=""; int technicalId=0;
            List<ProjectListDTO> projects = new List<ProjectListDTO>();
            try
            {
                Project project = new Project();
                projects = project.GetProject(name, technicalId);

                if (projects.Any())
                {
                    return projects;
                }
                //var content = new StringContent(JsonConvert.SerializeObject(projects),
                //                Encoding.UTF8, "application/json");

            }
            catch (Exception ex)
            {
                return null;
            }
            return projects;
        }

        [Route("Add")]
        [HttpPost]
        public ResponseDTO Add(ProjectListDTO projectListDTO)
        {
            var projects = new ResponseDTO();
            try
            {
                Project project = new Project();
                projects = project.AddProject(projectListDTO);
            }
            catch (Exception ex)
            {

            }
            return projects;
        }

        [Route("")]
        [HttpPut]
        public ResponseDTO UpdateProject(ProjectListDTO projectListDTO)
        {
            var projects = new ResponseDTO();
            try
            {
                Project project = new Project();
                projects = project.UpdateProject(projectListDTO);
            }
            catch (Exception ex)
            {

            }
            return projects;
        }

        [Route("")]
        [HttpDelete]
        public ResponseDTO DeleteProject(int projectId)
        {
            var projects = new ResponseDTO();
            try
            {
                Project project = new Project();
                projects = project.DeleteProject(projectId);
            }
            catch (Exception ex)
            {

            }
            return projects;
        }

        [Route("Save")]
        [AcceptVerbs("Post")]
        public HttpResponseMessage Save()
        {
            HttpResponseMessage response = null;
            try
            {
                if (System.Web.HttpContext.Current.Request.Files.AllKeys.Length > 0)
                {
                    var httpPostedFile = System.Web.HttpContext.Current.Request.Files["UploadFiles"];

                    if (httpPostedFile != null)
                    {
                        var fileSave = System.Web.HttpContext.Current.Server.MapPath("~/ProjectImages");
                        var fileName = DateTime.Now.ToString("yyyyMMddHHmmssfff") + "____" + httpPostedFile.FileName;
                        var fileSavePath = Path.Combine(fileSave, fileName );
                        var path=Url.Content("~/ProjectImages/"+fileName);
                        if (!System.IO.File.Exists(fileSavePath))
                        {
                            httpPostedFile.SaveAs(fileSavePath);
                            if (path != null)
                            {
                                return response = Request.CreateResponse(HttpStatusCode.OK, new { IsSuccess = true, FilePath = path });
                            }
                            else
                            {
                                response = Request.CreateResponse(HttpStatusCode.OK, new { IsSuccess = false });
                            }
                            HttpResponse res = System.Web.HttpContext.Current.Response;
                            res.Clear();
                            res.Headers.Add("Access-Control-Allow-Origin", "http://localhost:4200");
                            res.Headers.Add("path", path);
                            res.ContentType = "application/json; charset=utf-8";
                            res.StatusDescription = "File uploaded succesfully";
                            res.End();

                        }
                        else
                        {
                            HttpResponse Response = System.Web.HttpContext.Current.Response;
                            Response.Clear();
                            Response.Headers.Add("Access-Control-Allow-Origin", "http://localhost:4200");
                            Response.Status = "204 File already exists";
                            Response.StatusCode = 204;
                            Response.StatusDescription = "File already exists";
                            Response.End();
                            response = Request.CreateResponse(HttpStatusCode.OK, new { IsSuccess = false });

                        }
                    }
                }
            }
            catch (Exception e)
            {
                HttpResponse Response = System.Web.HttpContext.Current.Response;
                Response.Clear();
                Response.Headers.Add("Access-Control-Allow-Origin", "http://localhost:4200");
                Response.ContentType = "application/json; charset=utf-8";
                Response.StatusCode = 204;
                Response.Status = "204 No Content";
                Response.StatusDescription = e.Message;
                Response.End();
                response = Request.CreateResponse(HttpStatusCode.InternalServerError, new { IsSuccess = false });

            }
            return response;
        }
 

    }
}

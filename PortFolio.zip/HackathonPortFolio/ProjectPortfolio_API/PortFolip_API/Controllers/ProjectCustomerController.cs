﻿using PortFolio_BusinessLayer;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;

namespace PortFolip_API.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]

    [RoutePrefix("api/projectcustomer")]
    public class ProjectCustomerController : ApiController
    {
        public ProjectCustomerController()
        {

        }


        [HttpGet]
        public List<ProjectCustomerDTO> GetProjectCustomers(int projectId = 0)
        {
            var response = new ResponseDTO();
            List<ProjectCustomerDTO> projectCustomerDTOs = new List<ProjectCustomerDTO>();
            try
            {
                ProjectCustomerBL projectCustomerBL = new ProjectCustomerBL();
                var projectCustomer = projectCustomerBL.GetProjectCustomers(projectId);
                if (projectCustomer.Any())
                {
                    projectCustomerDTOs = projectCustomer;
                }
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
            }
            return projectCustomerDTOs;
        }

        [HttpPost]
        public ResponseDTO AddOrUpdateProjectCustomer(ProjectCustomerDTO projectCustomerDTO)
        {
            var response = new ResponseDTO();
            try
            {
                ProjectCustomerBL projectCustomerBL = new ProjectCustomerBL();
                var projectCustomerResponse = projectCustomerBL.AddOrUpdateProjectCustomer(projectCustomerDTO);
                if (projectCustomerResponse.IsSuccess)
                {
                    response.IsSuccess = true;
                    response.UserMessage = projectCustomerDTO.Id > 0 ? "Project customer successfully updated" : "Project customer successfully added.";
                }
                else
                {
                    response = projectCustomerResponse;
                }
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
            }
            return response;
        }

        [HttpDelete]
        public ResponseDTO DeleteProjectCustomer(int domineId)
        {
            var response = new ResponseDTO();
            try
            {
                ProjectCustomerBL projectCustomerBL = new ProjectCustomerBL();
                var projectCustomerResponse = projectCustomerBL.DeleteProjectCustomer(domineId);
                if (projectCustomerResponse.IsSuccess)
                {
                    response.IsSuccess = true;
                    response.UserMessage = "Project customer successfully deleted.";
                }
                else
                {
                    response = projectCustomerResponse;
                }
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
            }
            return response;
        }

        [Route("{getbygenericdomine}")]
        [HttpGet]
        public List<ProjectListDTO> GetByGenericDomine(int domineID)
        {
            List<ProjectListDTO> projectListDTOs = new List<ProjectListDTO>();
            try
            {

            }
            catch(Exception ex)
            {

            }
            return projectListDTOs;
        }
    }
}

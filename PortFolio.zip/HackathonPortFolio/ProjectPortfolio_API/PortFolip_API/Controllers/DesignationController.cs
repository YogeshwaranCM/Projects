﻿using PortFolio_BusinessLayer;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace PortFolip_API.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    [RoutePrefix("api/designation")]
    public class DesignationController : ApiController
    {
        public DesignationController()
        {
               
        }

        [HttpGet]
        public List<DesignationDTO> GetDesignations()
        {
            List<DesignationDTO> designations = new List<DesignationDTO>();
            try
            {
                DesignationBL designationBL = new DesignationBL();
                var designationDTOs = designationBL.GetDesignations();
                if(designationDTOs.Any())
                {
                    designations = designationDTOs;
                }
            }
            catch(Exception ex)
            {

            }
            return designations;
        }
    }
}

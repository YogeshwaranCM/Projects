﻿using PortFolio_BusinessLayer;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace PortFolip_API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class GeneralDomineController : ApiController
    {
        public GeneralDomineController()
        {
                
        }
        
        [HttpGet]
        public List<GeneralDomainDTO> GetGeneralDomains(string name)
        {
            List<GeneralDomainDTO> generalDomainDTOs = new List<GeneralDomainDTO>();
            try
            {
                GeneralDomineBL generalDomineBL = new GeneralDomineBL();
                var generalDomine = generalDomineBL.GetGeneralDomains();
                if(generalDomine.Any())
                {
                    generalDomainDTOs = generalDomine;
                }
            }
            catch(Exception ex)
            {

            }
            return generalDomainDTOs;
        }

        [HttpPost]
        public ResponseDTO AddOrUpdateGeneralDomine(GeneralDomainDTO generalDomainDTO)
        {
            var response = new ResponseDTO();
            try
            {
                GeneralDomineBL generalDomineBL = new GeneralDomineBL();
                var generalDomineResponse = generalDomineBL.AddOrUpdateGeneralDomine(generalDomainDTO);
                if(generalDomineResponse.IsSuccess)
                {
                    response.IsSuccess = true;
                    response.UserMessage = generalDomainDTO.Id > 0 ? "General domine successfully updated" : "General domine successfully added.";
                }
                else
                {
                    response = generalDomineResponse;
                }
            }
            catch (Exception ex)
            {

            }
            return response;
        }

        [HttpDelete]
        public ResponseDTO DeleteGeneralDomine(int domineId)
        {
            var response = new ResponseDTO();
            try
            {
                GeneralDomineBL generalDomineBL = new GeneralDomineBL();
                var generalDomineResponse = generalDomineBL.DeleteGeneralDomine(domineId);
                if(generalDomineResponse.IsSuccess)
                {
                    response.IsSuccess = true;
                    response.UserMessage = "General domine successfully deleted.";
                }
                else
                {
                    response = generalDomineResponse;
                }
            }
            catch (Exception ex)
            {

            }
            return response;
        }
    }
}

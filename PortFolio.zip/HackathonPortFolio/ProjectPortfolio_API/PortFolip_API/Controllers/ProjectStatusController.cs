﻿using PortFolio_BusinessLayer;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace PortFolip_API.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]

    [RoutePrefix("api/projectstatus")]
    public class ProjectStatusController : ApiController
    {
        public ProjectStatusController()
        {

        }

        [HttpGet]
        public List<ProjectStatusDTO> GetProjectStatus()
        {
            List<ProjectStatusDTO> projectStatusDTOs = new List<ProjectStatusDTO>();
            try
            {                
                ProjectStatusBL projectStatusBL = new ProjectStatusBL();
                var projectStatus = projectStatusBL.GetProjectStatus();
                if (projectStatus.Any())
                {
                    projectStatusDTOs = projectStatus;
                }
            }
            catch(Exception ex)
            {

            }
            return projectStatusDTOs;
        }

    }
}

﻿using PortFolio_BusinessLayer;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;

namespace PortFolip_API.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]

    [RoutePrefix("api/technicaldomine")]
    public class TechnicalDomineController : ApiController
    {
        public TechnicalDomineController()
        {

        }

        [HttpGet]
        public List<TechnicalDomainDTO> GetTechnicalDomains()
        {
            List<TechnicalDomainDTO> technicalDomainDTOs = new List<TechnicalDomainDTO>();
            try
            {
                TechnicalDomineBL technicalDomineBL = new TechnicalDomineBL();
                var technicalDomine = technicalDomineBL.GetTechnicalDomains();
                if (technicalDomine.Any())
                {
                    technicalDomainDTOs = technicalDomine;
                }
            }
            catch (Exception ex)
            {

            }
            return technicalDomainDTOs;
        }

        [HttpPost]
        public ResponseDTO AddOrUpdateTechnicalDomine(TechnicalDomainDTO TechnicalDomainDTO)
        {
            var response = new ResponseDTO();
            try
            {
                TechnicalDomineBL technicalDomineBL = new TechnicalDomineBL();
                var technicalDomineResponse = technicalDomineBL.AddOrUpdateTechnicalDomine(TechnicalDomainDTO);
                if (technicalDomineResponse.IsSuccess)
                {
                    response.IsSuccess = true;
                    response.UserMessage = TechnicalDomainDTO.Id > 0 ? "Technical domine successfully updated" : "Technical domine successfully added.";
                }
                else
                {
                    response = technicalDomineResponse;
                }
            }
            catch (Exception ex)
            {

            }
            return response;
        }

        [HttpDelete]
        public ResponseDTO DeleteTrechnicalDomine(int domineId)
        {
            var response = new ResponseDTO();
            try
            {
                TechnicalDomineBL technicalDomineBL = new TechnicalDomineBL();
                var technicalDomineResponse = technicalDomineBL.DeleteTechnicalDomine(domineId);
                if (technicalDomineResponse.IsSuccess)
                {
                    response.IsSuccess = true;
                    response.UserMessage = "Technical domine successfully deleted.";
                }
                else
                {
                    response = technicalDomineResponse;
                }
            }
            catch (Exception ex)
            {

            }
            return response;
        }
    }
}

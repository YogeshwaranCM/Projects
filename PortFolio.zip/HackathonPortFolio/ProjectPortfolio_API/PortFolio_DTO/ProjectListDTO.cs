﻿using System;

namespace PortFolio_DTO
{
    public class ProjectListDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime StartedDate { get; set; }
        public DateTime? CompletedDate { get; set; }
        public int? StatusId { get; set; }
        public int GeneralDomainId { get; set; }
        public int TechnicalDomainId { get; set; }
        public int ProjectCustomerId { get; set; }
        public bool? IsPublic { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool IsDeleted { get; set; }
        public string ProjectSiteLink { get; set; }

        public string Url { get; set; }

        public string CustomerName { get; set; }
        public string CompanyName { get; set; }
        public string Address { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public DateTime CreatedDate { get; set; }


        public string MemberName { get; set; }
        public bool IsActive { get; set; }
        public int EmployeeId { get; set; }
        public int DesignationId { get; set; }

        public string ControlName { get; set; }
        public bool? IsSyncfusionControl { get; set; }
        public string SiteLink { get; set; }
    }
}

﻿namespace PortFolio_DTO
{
    public class ResponseDTO
    {
        public string UserMessage { get; set; }

        public string ErrorMessage { get; set; }

        public bool IsSuccess { get; set; }

        public string Status { get; set; }
    }
}

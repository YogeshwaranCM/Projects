﻿namespace PortFolio_DTO
{
    public class ProjectControlDTO
    {
        public int Id { get; set; }
        public int ProjectId { get; set; }
        public string ControlName { get; set; }
        public bool IsSyncfusionControl { get; set; }
        public int MyProperty { get; set; }
        public string SiteLink { get; set; }
    }
}

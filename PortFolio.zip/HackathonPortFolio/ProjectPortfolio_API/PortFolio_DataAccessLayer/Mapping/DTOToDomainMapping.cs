﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortFolio_DataAccessLayer.Mapping
{
    public class DTOToDomainMapping : Profile
    {
        public DTOToDomainMapping()
        {

        }
    }
}

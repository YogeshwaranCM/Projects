﻿using AutoMapper;

namespace PortFolio_DataAccessLayer.Mapping
{
    public class AutoMapperConfiguration
    {
        public static void Configure()
        {
            Mapper.Initialize(cfg => {
                cfg.AddProfile<DTOToDomainMapping>();
                cfg.AddProfile<DomainToDTOMapping>();
            });
        }
    }
}

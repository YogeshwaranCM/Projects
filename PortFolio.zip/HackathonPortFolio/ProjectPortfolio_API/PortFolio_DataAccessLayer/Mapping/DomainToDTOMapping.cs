﻿using AutoMapper;
using PortFolio_DataAccessLayer.Data;
using PortFolio_DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortFolio_DataAccessLayer.Mapping
{
    public class DomainToDTOMapping : Profile
    {
        public DomainToDTOMapping()
        {
            CreateMap<ProjectList, ProjectListDTO>();
            CreateMap<GeneralDomain, GeneralDomainDTO>();
            CreateMap<ProjectControl, ProjectControlDTO>();
            CreateMap<ProjectCustomer, ProjectCustomerDTO>();
            CreateMap<ProjectMembers, ProjectMembersDTO>();
            CreateMap<ProjectStatus, ProjectStatusDTO>();
            CreateMap<TechnicalDomain, TechnicalDomainDTO>();
            CreateMap<Designation, DesignationDTO>();
        }
    }
}

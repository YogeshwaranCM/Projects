﻿import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LayoutComponentComponent } from './layout-component/layout-component.component'
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponentComponent } from './home-component/home-component.component';
import { ProjectInfoComponent } from './project-info/project-info.component'; 

const appRoutes: Routes = [
    //{ path: '', redirectTo: 'Login', pathMatch: 'full' },
    { path: 'Login', component: LoginComponent },
    {
        path: '',
        component: LayoutComponentComponent,
        children: [
          { path: '', redirectTo: 'projects', pathMatch: 'full' },
          { path: 'login', component: LoginComponent },
           { path: 'projects', component: DashboardComponent },
           { path: 'dashboard', component: HomeComponentComponent },
           {path: 'addproject', component: ProjectInfoComponent}
  
        ]
    }
];

export const routing: ModuleWithProviders =
    RouterModule.forRoot(appRoutes);

import { JwtHelperService } from '@auth0/angular-jwt';
import { CookieService } from 'ngx-cookie-service';
import { Injectable } from '@angular/core';
import { ReturnStatement } from '@angular/compiler/src/output/output_ast';

export class LocalStorageSection {
    private cookieService: CookieService=new CookieService(document);
    constructor() { }
    public tokenObjects: TokenObjectKeys = new TokenObjectKeys();
    //Set json type local storage
    setLocalStorage(key: string, value: any) {
        localStorage.setItem(key, JSON.stringify(value))
    }
    //get json type local storage
    getLocalStorage(key: string) {
        return JSON.parse(localStorage.getItem(key));
    }
    //get decoded token based on key
    getDecodedToken(key: string): any {
        const helper = new JwtHelperService();
        var token = this.cookieService.get("userToken");
        var decodedToken = "";
        var value = "";
        if (token != "" && token != null && token != undefined)
            decodedToken = helper.decodeToken(token);
        if (decodedToken != "" && decodedToken != null)
            value = decodedToken[key];
        return value
    }
    //check the current logged user token expired
    isTokenExpired(): boolean{
        const helper = new JwtHelperService();
        var token = this.cookieService.get("userToken");
        var isExpired = true;
        if (token!="" && token != null && token != undefined)
         isExpired = helper.isTokenExpired(token);
        return isExpired;
    }
    //set cookie by key value
    setCookie(key: string, value: string) {
        const helper = new JwtHelperService();
        let expirationDate = null;
        if (key == "userToken" && value!="")
            expirationDate = helper.getTokenExpirationDate(value);
        this.cookieService.set(key, value, expirationDate,'/');
    }
    //get cookie by key 
    getCookie(key: string) {
       return this.cookieService.get(key);
    }
    //delete cookie by key, if key is null delete all document cookie
    deleteCookie(key: string) {
        if (key == null)
            this.cookieService.deleteAll('/')
        else
            this.cookieService.delete(key,'/');
    }

    GetTrailExpiryDaysCount() {
        var trailDays = this.getCookie("trailDays");
        if (trailDays != "")
            return trailDays;
            return null;
    }
   
}


export class TokenObjectKeys {
    public isRemember: string = "IsRemember";
    public userName: string = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
    public userRole: string = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
    public userDashboardUrl: string = "UserDashboardURL";
    public serverOffset: string = "ServerOffset";
    public isTrailPlan: string = "IsTrailPlan";
    public trailExpiryIndicationDays: string = "TrailExpiryIndicationDays";
    public planExpiryDate: string = "PlanExpiryDate";
    public UserId: any = "UserId";
}
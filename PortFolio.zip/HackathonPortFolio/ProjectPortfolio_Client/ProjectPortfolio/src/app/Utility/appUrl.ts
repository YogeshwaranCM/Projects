export const loginUrl:string="/Login"
export const signupUrl:string="/SignUp"
export const baseUrl:string="http://localhost:57395/"
export const getUserRole: string = "/api/Account/GetAllProfileRolesAndFamilys";
export const saveUser: string = "/api/Account/CreatePerson";
export const loginUser: string = "/api/Account/AuthenticateUser";



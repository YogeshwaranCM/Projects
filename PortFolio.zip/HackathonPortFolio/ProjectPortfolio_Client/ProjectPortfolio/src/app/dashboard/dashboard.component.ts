import { Component, ViewChild, ViewEncapsulation, OnInit } from '@angular/core';
import {ApiService} from '../Service/apiService' ;
import { PagerComponent } from '@syncfusion/ej2-angular-grids';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
declare var $:any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
 AllProjectList:object[];
 @ViewChild('PagerComp') public pagercomp: PagerComponent;
  constructor(public apiService:ApiService) {

   }
   public fitername:any='';
   index:any=0;
   public selectedProjectIndex:any='';
   projectName:any="";
   @ViewChild('myModal') myModal;
  ngOnInit() {
     
    this.AllProjectList=[
      {projectName:"Clear drive",ProjectStatus:"On going", ProjectLogo:"./assets/logo.jpg"},
      {projectName:"Voice force",ProjectStatus:"New", ProjectLogo:"./assets/download.jpg"},
      {projectName:"Orion",ProjectStatus:"Finished", ProjectLogo:"./assets/download1.PNG"},
      {projectName:"Realrad",ProjectStatus:"On going", ProjectLogo:"./assets/download.jpg"},
         {projectName:"Meta",ProjectStatus:"On going", ProjectLogo:"./assets/logo.jpg"},
      {projectName:"Reload",ProjectStatus:"New", ProjectLogo:"./assets/download.jpg"},
      {projectName:"Event analyzer",ProjectStatus:"Finished", ProjectLogo:"./assets/download1.PNG"},
      {projectName:"Consulting",ProjectStatus:"On going", ProjectLogo:"./assets/download.jpg"},
         {projectName:"Data",ProjectStatus:"On going", ProjectLogo:"./assets/logo.jpg"},
      {projectName:"Drive",ProjectStatus:"New", ProjectLogo:"./assets/download.jpg"},
      {projectName:"Latest",ProjectStatus:"Finished", ProjectLogo:"./assets/download1.PNG"},
      {projectName:"Viveks",ProjectStatus:"On going", ProjectLogo:"./assets/download.jpg"},
         {projectName:"Viveks",ProjectStatus:"On going", ProjectLogo:"./assets/logo.jpg"},
      {projectName:"Viveks",ProjectStatus:"New", ProjectLogo:"./assets/download.jpg"},
      {projectName:"Viveks",ProjectStatus:"Finished", ProjectLogo:"./assets/download1.PNG"},
      {projectName:"Viveks",ProjectStatus:"On going", ProjectLogo:"./assets/download.jpg"},
      ]
      this.take=this.calculatedPageSize;
      this.projectList=this.AllProjectList.slice(this.skip,this.take);
  }
  skip:any=0;
  take:any=8;
calculatedPageSize:any = (Math.round(((window.innerHeight-100) / 270) - 0.5)) * (Math.round(((window.innerWidth) / 270) - 1));
projectList:any[];
   //To handle pager next and previous
   ChangePage(event: any) {
      if (event.currentPage) {
         this.take=this.calculatedPageSize;
          this.skip = (this.take * event.currentPage) -this.take;
          if (!this.skip) {
              this.skip = 0;
          }
          this.take=this.skip+this.take;
          this.projectList=this.AllProjectList.slice(this.skip,this.take);
      }
     
  }
  ChangeImage(event: any) {
   if (event.currentPage) {
    this.activeIndex=event.currentPage-1;
   }
  
}
  viewProject(project:any,istrue:any){
   for(var i=0;i<this.projectList.length;i++){
      this.projectList[i].IsShownDetails=false;
   }
   project.IsShownDetails= !istrue;

   // var tooltipsData:any =this.projectList.filter(function (element:any, index) {
   //    return (element.IsShownDetails === true);
   // });   
  }
  DeleteProject(index:any){
     this.apiService.loadingPopup=true;
     $("#DeleteConfirmModal").modal('hide');
     this.projectList.splice(index,1);
     var loading=this.apiService;
     //this.ChangePage(this.pagercomp);
     setTimeout(function(){
      loading.loadingPopup=false;
     },1000)
  }
  selectedViewProject:any=[];
  activeIndex:any=0;
  filtername:string="";
   
  
}


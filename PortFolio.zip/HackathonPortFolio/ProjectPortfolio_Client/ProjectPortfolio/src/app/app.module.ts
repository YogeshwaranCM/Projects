import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { routing  } from './app.routing'
import { JwtModule } from '@auth0/angular-jwt';
import { CookieService } from 'ngx-cookie-service';
import {ApiService} from './Service/apiService' ;
import { LocalStorageSection } from './Utility/localStorage';
import {HttpRequestInterceptor} from './Service/HttpRequestInterceptor';
import { LayoutComponentComponent } from './layout-component/layout-component.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GridAllModule , PagerModule } from '@syncfusion/ej2-angular-grids';
import { UploaderModule } from '@syncfusion/ej2-ng-inputs';
import { DropDownListModule, ComboBoxModule, MultiSelectModule } from '@syncfusion/ej2-ng-dropdowns';
import { DropDownButtonModule, SplitButtonModule } from '@syncfusion/ej2-angular-splitbuttons';
import { HomeComponentComponent } from './home-component/home-component.component';
import { SwitchModule } from '@syncfusion/ej2-angular-buttons';
import { ProjectInfoComponent } from './project-info/project-info.component';
import { DatePickerModule } from '@syncfusion/ej2-ng-calendars';
import {LocationStrategy, HashLocationStrategy} from '@angular/common';
import { APP_BASE_HREF } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LayoutComponentComponent,
    DashboardComponent,
    HomeComponentComponent,
    ProjectInfoComponent,
   
  ],
  imports: [
    BrowserModule,
    routing,
    HttpClientModule,
    JwtModule,
    DropDownButtonModule,
    SplitButtonModule,
    PagerModule,
    UploaderModule,
    FormsModule,
    DropDownListModule, ComboBoxModule, MultiSelectModule,SwitchModule,GridAllModule,DatePickerModule
  ],
  providers: [ApiService,LocalStorageSection,CookieService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

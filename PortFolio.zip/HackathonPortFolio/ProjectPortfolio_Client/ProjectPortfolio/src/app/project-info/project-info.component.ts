

import { Component,OnInit ,ViewChild, Inject, Output, EventEmitter, ViewEncapsulation, ViewChildren } from '@angular/core';
import { UploaderComponent, SelectedEventArgs } from '@syncfusion/ej2-ng-inputs';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import * as apiLinks from '../Utility/apilinks';
import { ApiService} from '../Service/apiService';
import { MultiSelectComponent, CheckBoxSelectionService } from '@syncfusion/ej2-ng-dropdowns';

@Component({
  selector: 'app-project-info',
  templateUrl: './project-info.component.html',
  styleUrls: ['./project-info.component.scss'],
  providers: [CheckBoxSelectionService]

})
export class ProjectInfoComponent implements OnInit {
public mode:string;
  constructor(public apiService:ApiService) {

    this.mode = 'CheckBox';

   }
  ngOnInit()
  {
    this.getAllDomain();

  }
  public projectDetailModel: ProjectInfoModel = new ProjectInfoModel();
  public generalDomainfields: Object = { text: 'Name', value: 'Id' };
  public technicalDomainfields: Object = { text: 'Name', value: 'Id' };
  public controlfields: Object = { text: 'Name', value: 'Id' };
  public GeneralDomainCollection: any = [{ Name: 'E-commerce', Id: '1' },
  { Name: 'Medicine', Id: '2' },
  { Name: 'banking', Id: '3' },
  { Name: 'Entertainment', Id: '4' }];
  public TechnicalDomainCollection: any = [{ Name: 'Asp MVC', Id: '1' },
  { Name: 'Xamarin', Id: '2' },
  { Name: 'Wpf', Id: '3' },
  { Name: 'Ios', Id: '4' }];;
  public SyncfusionControlCollection: { [key: string]: Object }[] =[{ Name: 'Web Angular Grid', Id: '1' },
  { Name: 'Web jsChart', Id: '2' },
  { Name: 'Wpf Grid', Id: '3' },
  { Name: 'Ios tools', Id: '4' }];
   public istechnicalCustom:boolean=false;
  public isgeneralCustom:boolean=false;

  @ViewChild('Modules')
  public uploadObj: UploaderComponent;
  public path: Object = {
    saveUrl: 'http://localhost:57395/api/projects/Save'
  };
  public buttons: Object = {
    browse: 'UPLOAD',
};
  public OnFileSelect(args: any, isScript: boolean): void {
    args.currentRequest.setRequestHeader("Access-Control-Allow-Origin", "*");
    args.currentRequest.setRequestHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");  
  }
public onFileUpload(args: any){
};
public OnSuccess(args: any, isScript: boolean) {
  var path = "";
  if (args && args.e && args.e.target && args.e.target.response) {
      var responseObj = JSON.parse(args.e.target.response);
      if (responseObj.FilePath) {
          path = decodeURI(responseObj.FilePath);
      }
  }
}

public getAllDomain()
{
  this.apiService.get('api/projects/getprojects').subscribe(
    data => {
    });
}

public Add()
{
  var data={projectListDTO:this.projectDetailModel};
  this.apiService.post("api/projects/Add",data).subscribe(
    data => {
    });
}
}


export class ProjectInfoModel {
  public ProjectName: string = '';
 public SyncfusionControlId:any=0;
  public ProjectId: number = 0;
  public ProjectStartDate: Date = new Date(new Date().setDate(new Date().getDate() + 1));
  public ProjectEndDate: Date = new Date(new Date().setDate(new Date().getDate() + 1));
  public ProjectDeadline: Date = new Date();
  public GenralDomainId: number = 0;
  public TechnicalDomainId: number = 0;
  public GenralDomainName: string = '';
  public TechnicalDomainName: string = '';
  public Description:string='';
  public ThirdPartyControl:string='';
}

import { Component, OnInit, ViewChild } from '@angular/core';
import { orderDetails } from './data';
import { SwitchComponent } from '@syncfusion/ej2-angular-buttons';
import { GridComponent } from '@syncfusion/ej2-angular-grids';
import { ApiService } from '../Service/apiService';

@Component({
  selector: 'app-home-component',
  templateUrl: './home-component.component.html',
  styleUrls: ['./home-component.component.scss']
})
export class HomeComponentComponent implements OnInit {
  public gridData: any;
  constructor(private apiService: ApiService) { }
  public data: Object[] = [];
  ngOnInit() {
    this.data = orderDetails;
    this.apiService.get('api/projects/GetProjects').subscribe(result => {
      this.gridData = result;
    })
  }
  @ViewChild('switch')
  public switch: SwitchComponent;

}


import { DataUtil } from "@syncfusion/ej2-data";

let stringData = JSON.stringify([
  {
    
    "CustomerID": "VINET",
    "OrderDate": "1996-07-04T00:00:00.000Z",
    "ShippedDate": "1996-07-16T00:00:00.000Z",
     "ShipName": "Vins et alcools Chevalier",
     "ShipCountry": "France"
  },
  {
    
    "CustomerID": "TOMSP",
    "OrderDate": "1996-07-05T00:00:00.000Z",
    "ShippedDate": "1996-07-10T00:00:00.000Z",
    "ShipName": "Toms Spezialitäten",
    "ShipCountry": "Angular"
  },
  {
    "OrderID": 10250,
    "CustomerID": "HANAR",
    "OrderDate": "1996-07-08T00:00:00.000Z",
    "ShippedDate": "1996-07-12T00:00:00.000Z",
    "Freight": 65.83,
    "ShipName": "Hanari Carnes",
    "ShipAddress": "Rua do Paço, 67",
    "ShipCity": "Rio de Janeiro",
    "ShipRegion": "RJ",
    "ShipCountry": "Js"
  },
  {
    "OrderID": 10251,
    "CustomerID": "VICTE",
    "OrderDate": "1996-07-08T00:00:00.000Z",
    "ShippedDate": "1996-07-15T00:00:00.000Z",
    "Freight": 41.34,
    "ShipName": "Victuailles en stock",
    "ShipAddress": "2, rue du Commerce",
    "ShipCity": "Lyon",
    "ShipRegion": null,
    "ShipCountry": "React"
  },
  {
    "OrderID": 10252,
    "CustomerID": "SUPRD",
    "OrderDate": "1996-07-09T00:00:00.000Z",
    "ShippedDate": "1996-07-11T00:00:00.000Z",
    "Freight": 51.3,
    "ShipName": "Suprêmes délices",
    "ShipAddress": "Boulevard Tirou, 255",
    "ShipCity": "Charleroi",
    "ShipRegion": null,
    "ShipCountry": "ionic"
  },
  {
    "OrderID": 10253,
    "CustomerID": "HANAR",
    "OrderDate": "1996-07-10T00:00:00.000Z",
    "ShippedDate": "1996-07-16T00:00:00.000Z",
    "Freight": 58.17,
    "ShipName": "Hanari Carnes",
    "ShipAddress": "Rua do Paço, 67",
    "ShipCity": "Rio de Janeiro",
    "ShipRegion": "RJ",
    "ShipCountry": "C#"
  },
  {
    "OrderID": 10254,
    "CustomerID": "CHOPS",
    "OrderDate": "1996-07-11T00:00:00.000Z",
    "ShippedDate": "1996-07-23T00:00:00.000Z",
    "Freight": 22.98,
    "ShipName": "Chop-suey Chinese",
    "ShipAddress": "Hauptstr. 31",
    "ShipCity": "Bern",
    "ShipRegion": null,
    "ShipCountry": "Java"
  },
  {
    "OrderID": 10255,
    "CustomerID": "RICSU",
    "OrderDate": "1996-07-12T00:00:00.000Z",
    "ShippedDate": "1996-07-15T00:00:00.000Z",
    "Freight": 148.33,
    "ShipName": "Richter Supermarkt",
    "ShipAddress": "Starenweg 5",
    "ShipCity": "Genève",
    "ShipRegion": null,
    "ShipCountry": "Android"
  },
  {
    "OrderID": 10256,
    "CustomerID": "WELLI",
    "OrderDate": "1996-07-15T00:00:00.000Z",
    "ShippedDate": "1996-07-17T00:00:00.000Z",
    "Freight": 13.97,
    "ShipName": "Wellington Importadora",
    "ShipAddress": "Rua do Mercado, 12",
    "ShipCity": "Resende",
    "ShipRegion": "SP",
    "ShipCountry": "Ios"
  },
  {
    "OrderID": 10257,
    "CustomerID": "HILAA",
    "OrderDate": "1996-07-16T00:00:00.000Z",
    "ShippedDate": "1996-07-22T00:00:00.000Z",
    "Freight": 81.91,
    "ShipName": "HILARION-Abastos",
    "ShipAddress": "Carrera 22 con Ave. Carlos Soublette #8-35",
    "ShipCity": "San Cristóbal",
    "ShipRegion": "Táchira",
    "ShipCountry": "Angular"
  },
  {
    "OrderID": 10258,
    "CustomerID": "ERNSH",
    "OrderDate": "1996-07-17T00:00:00.000Z",
    "ShippedDate": "1996-07-23T00:00:00.000Z",
    "Freight": 140.51,
    "ShipName": "Ernst Handel",
    "ShipAddress": "Kirchgasse 6",
    "ShipCity": "Graz",
    "ShipRegion": null,
    "ShipCountry": "Android"
  },
  {
    "OrderID": 10259,
    "CustomerID": "CENTC",
    "OrderDate": "1996-07-18T00:00:00.000Z",
    "ShippedDate": "1996-07-25T00:00:00.000Z",
    "Freight": 3.25,
    "ShipName": "Centro comercial Moctezuma",
    "ShipAddress": "Sierras de Granada 9993",
    "ShipCity": "México D.F.",
    "ShipRegion": null,
    "ShipCountry": "C#"
  },
  {
    "OrderID": 10260,
    "CustomerID": "OTTIK",
    "OrderDate": "1996-07-19T00:00:00.000Z",
    "ShippedDate": "1996-07-29T00:00:00.000Z",
    "Freight": 55.09,
    "ShipName": "Ottilies Käseladen",
    "ShipAddress": "Mehrheimerstr. 369",
    "ShipCity": "Köln",
    "ShipRegion": null,
    "ShipCountry": "Js"
  },
  {
    "OrderID": 10261,
    "CustomerID": "QUEDE",
    "OrderDate": "1996-07-19T00:00:00.000Z",
    "ShippedDate": "1996-07-30T00:00:00.000Z",
    "Freight": 3.05,
    "ShipName": "Que Delícia",
    "ShipAddress": "Rua da Panificadora, 12",
    "ShipCity": "Rio de Janeiro",
    "ShipRegion": "RJ",
    "ShipCountry": "TypeScript"
  },
  {
    "OrderID": 10262,
    "CustomerID": "RATTC",
    "OrderDate": "1996-07-22T00:00:00.000Z",
    "ShippedDate": "1996-07-25T00:00:00.000Z",
    "Freight": 48.29,
    "ShipName": "Rattlesnake Canyon Grocery",
    "ShipAddress": "2817 Milton Dr.",
    "ShipCity": "Albuquerque",
    "ShipRegion": "NM",
    "ShipCountry": "xamarin"
  },
  {
    "OrderID": 10263,
    "CustomerID": "ERNSH",
    "OrderDate": "1996-07-23T00:00:00.000Z",
    "ShippedDate": "1996-07-31T00:00:00.000Z",
    "Freight": 146.06,
    "ShipName": "Ernst Handel",
    "ShipAddress": "Kirchgasse 6",
    "ShipCity": "Graz",
    "ShipRegion": null,
    "ShipCountry": "C#"
  },
  {
    "OrderID": 10264,
    "CustomerID": "FOLKO",
    "OrderDate": "1996-07-24T00:00:00.000Z",
    "ShippedDate": "1996-08-23T00:00:00.000Z",
    "Freight": 3.67,
    "ShipName": "Folk och fä HB",
    "ShipAddress": "Åkergatan 24",
    "ShipCity": "Bräcke",
    "ShipRegion": null,
    "ShipCountry": "Java"
  },
  {
    "OrderID": 10265,
    "CustomerID": "BLONP",
    "OrderDate": "1996-07-25T00:00:00.000Z",
    "ShippedDate": "1996-08-12T00:00:00.000Z",
    "Freight": 55.28,
    "ShipName": "Blondel père et fils",
    "ShipAddress": "24, place Kléber",
    "ShipCity": "Strasbourg",
    "ShipRegion": null,
    "ShipCountry": "C#"
  },
]);
export const orderDetails: Object[] = JSON.parse(stringData, (field, value) => {
  let dupValue = value;
  if (typeof value === 'string' && /^(\d{4}\-\d\d\-\d\d([tT][\d:\.]*){1})([zZ]|([+\-])(\d\d):?(\d\d))?$/.test(value)) {
    let arr = dupValue.split(/[^0-9]/);
    value = new Date(parseInt(arr[0], 10), parseInt(arr[1], 10) - 1,
      parseInt(arr[2], 10), parseInt(arr[3], 10), parseInt(arr[4], 10), parseInt(arr[5], 10));
  }
  return value;
});

import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, BaseRequestOptions, Headers} from '@angular/http';
import { Observable, throwError } from 'rxjs';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/internal/operators/catchError';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { BehaviorSubject, Subject } from 'rxjs'; 
import * as apiLink from '../Utility/apilinks'
@Injectable()
export class ApiService {
    loadingPopup:any=false;
    baseUrl:string="http://localhost:57395/";
    constructor(private _http: HttpClient) {
    }
    private isShowUpgrade: BehaviorSubject<string> = new BehaviorSubject<string>("");

    get(url: string): Observable<any> {
        let headers = new HttpHeaders();
        return this._http.get(this.baseUrl+url, { headers: headers, observe: 'response' })
            .pipe(map((response: any) => this.ReturnResponseData(response)), catchError(this.handleError));
    }
    post(url: string, model: any): Observable<any> {
        let body = JSON.stringify(model);
        let headers = new HttpHeaders();
        headers = headers.set('Content-Type', 'application/json;charset=UTF-8');
        return this._http.post(apiLink.baseUrl+url, body, { headers: headers, observe:'response' })
            .pipe(map((response: any) => this.ReturnResponseData(response)), catchError(this.handleError));
    }

    put(url: string, id: number, model: any): Observable<any> {
        let body = JSON.stringify(model);
        let headers = new HttpHeaders();
        headers = headers.set('Content-Type', 'application/json;charset=UTF-8');
        return this._http.put(apiLink.baseUrl+url + id, body, { headers: headers })
            .pipe(map((response: any) => this.ReturnResponseData), catchError(this.handleError));

    }

    delete(url: string, id: number): Observable<any> {
        let headers = new HttpHeaders();
        headers = headers.set('Content-Type', 'application/json;charset=UTF-8');
        return this._http.delete(apiLink.baseUrl+url + id, { headers: headers })
            .pipe(map((response: Response) => <any>response), catchError(this.handleError));

    }
    private ReturnResponseData(response: any) {
        var header = response.headers;
        return response != null ? response.body : response;
    }
    private handleError(error: any) {
        var errorMessage = { Message: error.error != undefined ? error.error.Message : error.message }
            return throwError(errorMessage);
    }
 
}
﻿import { Injectable, Injector } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/internal/operators/catchError'; 
import { Router } from "@angular/router";
import { LocalStorageSection, TokenObjectKeys } from '../Utility/localStorage';
import * as appURL from '../Utility/appURL';
import * as apiLinks from '../Utility/apiLinks';

@Injectable()
export class HttpRequestInterceptor implements HttpInterceptor {
    constructor(private router: Router, public localStorage: LocalStorageSection) { }
    public tokenObjects: TokenObjectKeys = new TokenObjectKeys();
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(req);
        // if (req.url.indexOf('/Account') > 0) {
        //     var now = new Date();
        //     var tz = -now.getTimezoneOffset();
        //     const clonedreq = req.clone({ setHeaders: { 'TimeZone': tz.toString() } });
        //     return next.handle(clonedreq);
        // }
        // var userRole = this.localStorage.getDecodedToken(this.tokenObjects.userRole);  
        // if (!this.localStorage.isTokenExpired()) {
        //     var authHeader = "Bearer " + this.localStorage.getCookie('userToken');
        //     var now = new Date();
        //     var tz = -now.getTimezoneOffset();
        //     const clonedreq = req.clone({ setHeaders: { Authorization: authHeader, 'TimeZone': tz.toString()} });
        //     return next.handle(clonedreq).pipe(
        //         catchError((err) => {
        //             if (err instanceof HttpErrorResponse) {
        //                 if (err.status === 401) {
        //                  //   this.router.navigate([appURL.loginUrl]);
        //                 }
        //                 return throwError(err);
        //             }
        //         })
        //     );
        // }
        // else {
        //     this.router.navigate([appURL.loginUrl]);
        //     return throwError("Authentication failed");
        // }

    }
}
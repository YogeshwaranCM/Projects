import { Component, OnInit } from '@angular/core';
import { ItemModel, MenuEventArgs } from '@syncfusion/ej2-angular-splitbuttons';
import {ApiService} from '../Service/apiService' ;
declare var $:any;
@Component({
  selector: 'app-layout-component',
  templateUrl: './layout-component.component.html',
  styleUrls: ['./layout-component.component.scss']
})
export class LayoutComponentComponent implements OnInit {

  constructor(public apiService:ApiService) { }

  ngOnInit() {
//     setTimeout(()=>{ 
//       var bodyHeight=window.innerHeight-$(".menu").height()+$(".subMenu").height();
//       $(".bodyContent").css("height",bodyHeight+"px");
//  }, 1000);
  }
  public items: object[] = [
    {
      text: 'Dashboard',
      iconCss: 'e-ddb-icons e-dashboard'
    },
    {
      text: 'Notifications',
      iconCss: 'e-ddb-icons e-notifications',
    },
    {
      text: 'User Settings',
      iconCss: 'e-ddb-icons e-settings',
    },
    {
      text: 'Log Out',
      iconCss: 'e-ddb-icons e-logout'
    }];
 
    onResize(e){
      // var bodyHeight=window.innerHeight-$(".menu").height()+$(".subMenu").height();
      // $(".bodyContent").css("height",bodyHeight+"px");
    }

}
